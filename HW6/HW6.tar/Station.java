class Station {
    public String id;
    public String name;
    public String line;

    public Station(String id, String name, String line) {
        this.id = id;
        this.name = name;
        this.line = line;
    }

}
