class Edge {
    String toId;
    int time;

    public Edge(String toId, int time) {
        this.toId = toId;
        this.time = time;
    }
}